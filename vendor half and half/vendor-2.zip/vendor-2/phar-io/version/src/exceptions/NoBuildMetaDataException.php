<?php declare(strict_types = 1);
namespace PharIo\Version;

class NoBuildMetaDataException extends \Exception implements Exception {
}
