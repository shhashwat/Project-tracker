<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProjectController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/projects', [ProjectController::class, 'index'])->name('projects.index');
Route::get('/projects/create', [ProjectController::class, 'create'])->name('projects.create');
Route::post('/projects', [ProjectController::class, 'store'])->name('projects.store');
Route::get('/projects/{project}/edit', [ProjectController::class, 'edit'])->name('projects.edit');
Route::get('/projects/search',[ProjectController::class,'search'])->name('projects.search');
Route::get('projects/export', [ProjectController::class,'export'])->name('projects.export');
Route::get('/projects/filter', [ProjectController::class,'filter'])->name('projects.filter');
//Route::put('/projects/{project}', [ProjectController::class, 'update'])->name('projects.update');

Route::put('/projects/{project}', [ProjectController::class, 'update'])->name('projects.update');



