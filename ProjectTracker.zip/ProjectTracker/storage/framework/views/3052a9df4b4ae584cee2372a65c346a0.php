

<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="font-size:0.75rem;">
    <!-- Page Header -->
    <div>
        <div class="d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center align-content-center w-100">
                <div class="d-flex align-items-center justify-content-between" style="gap: 90px;">
                    <img src="<?php echo e(asset('images/627cc5c91b2e263b45696a8e.png')); ?>" alt="Company Logo" class="img-fluid logo" style="max-height: 120px;">
                    <h2 class="d-flex align-items-center justify-content-center text-gradient text-primary text-center m-0 flex-grow-1">
                        <p style="color: #0089d0;" >Digital Banking Department Project Tracking Sheet</p>
                    </h2>
                </div>
            </div>
        </div>
    </div>

    <style>
        .logo {
            margin-right: 90px;
        }

        @media (max-width: 1200px) {
            .logo {
                margin-right: 60px;
            }
        }

        @media (max-width: 992px) {
            .logo {
                margin-right: 40px;
            }
        }

        @media (max-width: 768px) {
            .logo {
                margin-right: 20px;
            }
        }

        @media (max-width: 576px) {
            .logo {
                margin-right: 10px;
            }
        }
    </style>

    <!-- Add New Project Button (Reduced Margin) -->
     <div style="display: flex; flex-direction: row; justify-content: space-between;" style="line-height: normal;">
         <div class="text-end mb-2 pe-3">
             <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-lg btn-success rounded" style="background: #34bdeb; outline: none; border: none;">
                 <i class="fas fa-plus"></i> Add New Row
             </a>
         </div>
         <div style="display: flex; flex-direction: row; gap: 0.5rem;">
            <div style="display: flex; flex-direction: row; gap: 0.5rem;">
                <form action="<?php echo e(route('projects.search')); ?>" method="GET">
                    <input
                    type="text"
                    name="search"
                    value="<?php echo e(request('search')); ?>"
                    style="
                        height: 3rem;
                        padding: 0 20px;
                        font-size: 1rem;
                        font-weight: 500;
                        border-weight: 5px;
                        border-radius: 8px;
                        cursor: pointer;
                        transition: background 0.2s ease-in-out, transform 0.15s;"
                    placeholder="Search"
                    />
                    <button type="submit"
                    title="Search"
                    style="
                        height: 3rem;
                        background-color: white;
                        font-size: 1rem;
                        font-weight: 500;
                        border-weight: 5px;
                        border-radius: 8px;
                        cursor: pointer;
                        transition: background 0.2s ease-in-out, transform 0.15s;
                        "
                    >🔍</button>
                </form>
            </div>
            <form action="<?php echo e(route('projects.filter')); ?>" method="GET">
                <select name="column" onchange="this.form.submit()" style="height: 3rem; padding: 0 20px; font-size: 1rem; font-weight: 500; border: none; background: #34bdeb; color: white; border-radius: 8px; cursor: pointer; transition: background 0.2s ease-in-out, transform 0.15s;">
                    <option value="">Filter</option>
                    <option value="description">Description</option>
                    <option value="status">Status</option>
                    <option value="expected_go_live">Expected to go live</option>
                    <option value="current_status">Current Status Details</option>
                </select>
            </form>
            
            <a href="<?php echo e(route('projects.export', request()->query())); ?>" 
                style="display: inline-block;
                        height: 3rem;
                        padding: 0 20px;
                        font-size: 1rem;
                        font-weight: 500;
                        border: none;
                        background: #34bdeb;
                        color: #333;
                        border-radius: 8px;
                        cursor: pointer;
                        text-decoration: none;
                        line-height: 3rem;
                        text-align: center;
                        transition: background 0.2s ease-in-out, transform 0.15s;">
                    <p style="color: white;" >Export</p>
            </a>
        </div>
     </div>

    <!-- Table Section -->
     <div class="table-responsive">
        <table class="table table-hover table-bordered shadow-lg text-wrap w-100">
            <thead class="text-white text-center align-middle" style="background-color: #0089d0;">
                <tr>
                    <th>SN</th>
                    <th>Project Name</th>
                    <th>
                        <?php if($column): ?>
                            <?php echo e(ucwords(str_replace('_', ' ', $column))); ?>

                        <?php else: ?>
                            Filtered Column
                        <?php endif; ?>
                    </th>
                </tr>
            </thead>
            <tbody class="text-center align-middle">
                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($project->id); ?></td>
                        <td><?php echo e($project->project_name); ?></td>
                        <td>
                            <?php if($column): ?>
                                <?php echo e($project->{$column}); ?>

                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">No projects found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

    <!-- Pagination -->
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($projects->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Project Tracker\ProjectTracker\resources\views/projects/filtered.blade.php ENDPATH**/ ?>