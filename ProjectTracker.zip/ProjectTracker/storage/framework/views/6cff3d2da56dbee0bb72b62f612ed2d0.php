<!DOCTYPE html>
<html>
<head>
    <title>Project Tracker</title>
  
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">


</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Project Tracker\ProjectTracker\resources\views/layouts/app.blade.php ENDPATH**/ ?>