

<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="font-size:0.75rem;">
    <!-- Page Header -->
    <div>
        <div class="d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center align-content-center w-100">
                <div class="d-flex align-items-center justify-content-between" style="gap: 90px;">
                    <img src="<?php echo e(asset('images/627cc5c91b2e263b45696a8e.png')); ?>" alt="Company Logo" class="img-fluid logo" style="max-height: 120px;">
                    <h2 class="d-flex align-items-center justify-content-center text-gradient text-primary text-center m-0 flex-grow-1">
                        <p style="color: #0089d0;" >Digital Banking Department Project Tracking Sheet</p>
                    </h2>
                </div>
            </div>
        </div>
    </div>

    <style>
        .logo {
            margin-right: 90px;
        }

        @media (max-width: 1200px) {
            .logo {
                margin-right: 60px;
            }
        }

        @media (max-width: 992px) {
            .logo {
                margin-right: 40px;
            }
        }

        @media (max-width: 768px) {
            .logo {
                margin-right: 20px;
            }
        }

        @media (max-width: 576px) {
            .logo {
                margin-right: 10px;
            }
        }
    </style>

    <!-- Add New Project Button (Reduced Margin) -->
     <div style="display: flex; flex-direction: row; justify-content: space-between;" style="line-height: normal;">
         <div class="text-end mb-2 pe-3">
             <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-lg btn-success rounded" style="background: #34bdeb; outline: none; border: none;">
                 <i class="fas fa-plus"></i> Add New Row
             </a>
         </div>
         <div style="display: flex; flex-direction: row; gap: 0.5rem;">
            <div style="display: flex; flex-direction: row; gap: 0.5rem;">
                <form action="<?php echo e(route('projects.search')); ?>" method="GET">
                    <input
                    type="text"
                    name="search"
                    value="<?php echo e(request('search')); ?>"
                    style="
                        height: 3rem;
                        padding: 0 20px;
                        font-size: 1rem;
                        font-weight: 500;
                        border-weight: 5px;
                        border-radius: 8px;
                        cursor: pointer;
                        transition: background 0.2s ease-in-out, transform 0.15s;"
                    placeholder="Search"
                    />
                    <button type="submit"
                    title="Search"
                    style="
                        height: 3rem;
                        background-color: white;
                        font-size: 1rem;
                        font-weight: 500;
                        border-weight: 5px;
                        border-radius: 8px;
                        cursor: pointer;
                        transition: background 0.2s ease-in-out, transform 0.15s;
                        "
                    >🔍</button>
                </form>
            </div>
            <!-- <select style="height: 3rem;
                    padding: 0 20px;
                    font-size: 1rem;
                    font-weight: 500;
                    border: none;
                    background: #34bdeb;
                    color: white;
                    border-radius: 8px;
                    cursor: pointer;
                    transition: background 0.2s ease-in-out, transform 0.15s;">
                    <option value="">Filter</option>
                    <option value="project_name">Project Name</option>
                    <option value="status">Status</option>
                    <option value="created_at">Date Created</option>
                    <option value="updated_at">Date Updated</option>
            </select> -->
            
            <form action="<?php echo e(route('projects.filter')); ?>" method="GET">
                <select name="column" onchange="this.form.submit()" style="height: 3rem; padding: 0 20px; font-size: 1rem; font-weight: 500; border: none; background: #34bdeb; color: white; border-radius: 8px; cursor: pointer; transition: background 0.2s ease-in-out, transform 0.15s;">
                    <option value="">Filter</option>
                    <option value="description">Description</option>
                    <option value="status">Status</option>
                    <option value="expected_go_live">Expected to go live</option>
                    <option value="current_status">Current Status Details</option>
                </select>
            </form>


            <a href="<?php echo e(route('projects.export', request()->query())); ?>" 
                style="display: inline-block;
                        height: 3rem;
                        padding: 0 20px;
                        font-size: 1rem;
                        font-weight: 500;
                        border: none;
                        background: #34bdeb;
                        color: #333;
                        border-radius: 8px;
                        cursor: pointer;
                        text-decoration: none;
                        line-height: 3rem;
                        text-align: center;
                        transition: background 0.2s ease-in-out, transform 0.15s;">
                    <p style="color: white;" >Export</p>
            </a>
        </div>
     </div>

    <!-- Table Section -->
    <div class="table-responsive">
        <table class="table table-hover table-bordered shadow-lg text-wrap w-100 td" style="table-layout: auto; line-height: normal;">
            <thead class="text-white text-center align-middle" style="background-color: #0089d0;">
                <tr>
                    <th>SN</th>
                    <th style="min-width: 150px;">User Department</th>
                    <th style="min-width: 200px;">Project Name</th>
                    <th style="min-width: 600px;">Description</th>
                    <th style="min-width: 200px;">Benefits of Project</th>
                    <th style="min-width: 200px;">Business Impact</th>
                    <th style="min-width: 150px;">RFP Floating Date</th>
                    <th>Vendor</th>
                    <th style="min-width: 150px;">PO Issue Date</th>
                    <th style="min-width: 150px;">PO Acceptance Date</th>
                    <th style="min-width: 150px;">Validity of PO (From Date)</th>
                    <th style="min-width: 150px;">Validity of PO (To Date)</th>
                    <th style="min-width: 150px;">SLA Date</th>
                    <th style="min-width: 200px;">Commercials (Rs.)</th>
                    <th style="min-width: 300px;">Category (Regulatory/Customer Centric/Back Office)</th>
                    <th style="min-width: 150px;">Payment Made Till Date</th>
                    <th style="min-width: 150px;">Last Date of Payment</th>
                    <th style="min-width: 150px;">UAT Start Date</th>
                    <th style="min-width: 150px;">UAT End Date</th>
                    <th style="min-width: 200px;">(Completed/In-Progress)</th>
                    <th style="min-width: 150px;">% Complete</th>
                    <th style="min-width: 600px;">Current Status Details</th>
                    <th style="min-width: 150px;">Expected Time to Go-Live</th>
                    <th style="min-width: 150px;">Actual Go-Live Date</th>
                    <th style="min-width: 200px;">Delay</th>
                    <th style="min-width: 300px;">Reason for Delay</th>
                    <!-- <th style="min-width: 250px;">Breakup of Payment with Dates</th>
                    <th>Priority</th>
                    <th style="min-width: 200px;">Activity Description</th>
                    <th style="min-width: 200px;">Task Owner</th>
                    <th style="min-width: 200px;">Remarks by Project Lead</th>
                    <th style="min-width: 200px;">Strategic Alignment</th>
                    <th style="min-width: 200px;">Dependence</th> -->
                    <th style="min-width: 200px;">Actions</th>
                </tr>
            </thead>
            <tbody class="text-center align-middle">
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($project->id); ?></td>
                    <td><?php echo e($project->user_department); ?></td>
                    <td><?php echo e($project->project_name); ?></td>
                    <td><?php echo e($project->description); ?></td>
                    <td><?php echo e($project->benefits_of_project); ?></td>
                    <td><?php echo e($project->business_impact); ?></td>
                    <td><?php echo e($project->rfp_floating_date); ?></td>
                    <td><?php echo e($project->vendor); ?></td>
                    <td><?php echo e($project->po_issue_date); ?></td>
                    <td><?php echo e($project->po_acceptance_date); ?></td>
                    <td><?php echo e($project->validity_of_po_from_date); ?></td>
                    <td><?php echo e($project->validity_of_po_to_date); ?></td>
                    <td><?php echo e($project->sla_date); ?></td>
                    <td><?php echo e($project->commercials); ?></td>
                    <td><?php echo e($project->category); ?></td>
                    <td><?php echo e($project->payment_made_till_date); ?></td>
                    <td><?php echo e($project->last_date_of_payment); ?></td>
                    <td><?php echo e($project->uat_start_date); ?></td>
                    <td><?php echo e($project->uat_end_date); ?></td>
                    <td><?php echo e($project->status); ?></td>
                    <td><strong><?php echo e($project->percentage_complete); ?>%</strong></td>
                    <td><?php echo e($project->current_status); ?></td>
                    <td><?php echo e($project->expected_go_live); ?></td>
                    <td><?php echo e($project->actual_go_live_date); ?></td>
                    <td><?php echo e($project->delay); ?></td>
                    <td><?php echo e($project->reason_for_delay); ?></td>
                    <!-- <td><?php echo e($project->breakup_of_payment_made_along_with_dates); ?></td>
                    <td><?php echo e($project->priority); ?></td>
                    <td><?php echo e($project->activity_description); ?></td>
                    <td><?php echo e($project->task_owner); ?></td>
                    <td><?php echo e($project->remarks_by_project_lead); ?></td>
                    <td><?php echo e($project->strategic_alignment); ?></td>
                    <td><?php echo e($project->dependence); ?></td> -->
                    <td>
                        <a href="<?php echo e(route('projects.edit', $project->id)); ?>" class="btn btn-primary btn-sm shadow">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($projects->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectTracker\resources\views/projects/index.blade.php ENDPATH**/ ?>