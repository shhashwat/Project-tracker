<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\Schema;
use App\Models\Project;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;


class ProjectController extends Controller
{
    public function index()
    {
        $projects = Project::paginate(15); // This returns a LengthAwarePaginator

        return view('projects.index', compact('projects'));
    }

    public function create()
    {   
        return view('projects.create');
    }

    public function store(Request $request)
{
    // dd($request->all());
   /* $request->validate([
        'project_name' => 'required',
        'description' => 'nullable',
        'current_status' => 'required',
       // 'expected_go_live' => 'nullable|date',
       // 'vendor_name' => 'required'
    ]);
*/
  Project::create($request->all()); 
/*
    Project::create([
        'project_name' => $request->project_name,
        'description' => $request->description,
        'current_status' => $request->current_status,
        //'expected_go_live' => $request->expected_go_live,
        //'vendor' => $request->vendor_name,
        
    ]); 
*/
    return redirect()->route('projects.index')->with('success', 'Project added successfully!');
}

    public function edit(Project $project)
    {
       //dd($project);
        return view('projects.edit', compact('project'));
    }

    public function update(Request $request, $id) 
    {
        $project = Project::findOrFail($id);
        $project->update($request->all());
        return redirect()->route('projects.index')->with('success', 'Project updated successfully!');
    }

    //SEARCHING ON SPECIFIED COLUMNS
    // public function search(Request $request){
    //     $search = $request->input('search');

    //     $projects = Project::where(function($query) use ($search) {
    //         $query->where('project_name', 'LIKE', '%' . $search . '%')
    //             ->orWhere('description', 'LIKE', '%' . $search . '%')
    //             ->orWhere('current_status', 'LIKE', '%' . $search . '%');
    //     })->paginate(15);

    //     return view('projects.index', compact('projects'));
    // }


    //SEARCH ALL COLUMNS FOR INPUT VALUES
    public function search(Request $request){
        $search = $request->input('search');
        $columns = Schema::getColumnListing('projects');

        $query = Project::query();

        $query->where(function($q) use ($columns, $search) {
            foreach ($columns as $column) {
                $q->orWhere($column, 'LIKE', '%' . $search . '%');
            }
        });

        $projects = $query->paginate(15);

        return view('projects.index', compact('projects'));
    }


    public function filter(Request $request)
    {
        $column = $request->input('column');

        if (!empty($column)) {
            $projects = Project::select('id', 'project_name', $column)->paginate(15)->appends(['column' => $column]);;
        } else {
            $projects = Project::select('id', 'project_name')->paginate(15);
        }

        return view('projects.filtered', compact('projects', 'column'));
    }

    public function export(Request $request){
        
        $fileName = 'projects_export_' . date('d-m-Y') . '.csv';

        $headers = [
            "Content-type" => "text/csv",
            "Content-Disposition" => "attachment; filename=$fileName",
            "Pragma" => "no-cache",
            "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
            "Expires" => "0"
        ];

        $callback = function () use ($request) {
            $file = fopen('php://output', 'w');

            // Define the header row for the CSV
            $columns = [
                'SN',
                'User Department',
                'Project Name',
                'Description',
                'Benefits of Project',
                'Business Impact',
                'RFP Floating Date',
                'Vendor',
                'PO Issue Date',
                'PO Acceptance Date',
                'Validity of PO (From Date)',
                'Validity of PO (To Date)',
                'SLA Date',
                'Commercials (Rs.)',
                'Category (Regulatory/Customer Centric/Back Office)',
                'Payment Made Till Date',
                'Last Date of Payment',
                'UAT Start Date',
                'UAT End Date',
                '(Completed/In-Progress)',
                '% Complete',
                'Current Status Details',
                'Expected Time to Go-Live',
                'Actual Go-Live Date',
                'Delay',
                'Reason for Delay',
            ];
            fputcsv($file, $columns);

            // Build your query; for example, applying a search filter if provided
            $query = Project::query();

            // If a search term is provided, filter by name or description
            if ($request->has('search') && !empty($request->search)) {
                $search = $request->search;
                $columns = Schema::getColumnListing('projects');

                $query->where(function($q) use ($columns, $search) {
                foreach ($columns as $column) {
                    $q->orWhere($column, 'LIKE', '%' . $search . '%');
                }});
            }
            
            $projects = $query->get();


            // Write each project's data into the CSV
            foreach ($projects as $project) {
                fputcsv($file, [
                    $project->id,
                    $project->user_department,
                    $project->project_name,
                    $project->description,
                    $project->benefits_of_project,
                    $project->business_impact,
                    $project->rfp_floating_date,
                    $project->vendor,
                    $project->po_issue_date,
                    $project->po_acceptance_date,
                    $project->validity_of_po_from_date,
                    $project->validity_of_po_to_date,
                    $project->sla_date,
                    $project->commercials,
                    $project->category,
                    $project->payment_made_till_date,
                    $project->last_date_of_payment,
                    $project->uat_start_date,
                    $project->uat_end_date,
                    $project->status,
                    $project->percentage_complete,
                    $project->current_status,
                    $project->expected_go_live,
                    $project->actual_go_live_date,
                    $project->delay,
                    $project->reason_for_delay
                ]);
            }

            fclose($file);
        };

        return new StreamedResponse($callback, 200, $headers);
    }

}
