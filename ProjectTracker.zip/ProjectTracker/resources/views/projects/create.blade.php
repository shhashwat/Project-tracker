@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-lg border-0 rounded-4">
                <div class="bg-primary card-header text-white text-center py-3">
                    <h2 class="mb-0">Add New Project</h2>
                </div>
                
                <div class="card-body p-4">
                    <form action="{{ route('projects.store') }}" method="POST">
                        @csrf
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Project Name:</label>
                                <input type="text" class="form-control shadow-sm" name="project_name"
                                required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">User department:</label>
                                <input type="text" class="form-control shadow-sm" name="user_department" value="Digital Banking Department">
                            </div>
                            
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Description:</label>
                            <textarea class="form-control shadow-sm" name="description" rows="3" placeholder="Enter project details"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Benefits of Project:</label>
                            <textarea class="form-control shadow-sm" name="benefits_of_project" rows="3"></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Business impact:</label>
                                <textarea type="text" class="form-control shadow-sm" name="business_impact"></textarea>
                            </div>
                            <div class="col-md-6 mb-3 ml-1.5">
                                <label class="form-label fw-bold">RFP Floating date:</label>
                                <input type="date" class="form-control shadow-sm" name="rfp_floating_date">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Vendor:</label>
                                <input type="text" class="form-control shadow-sm" name="vendor"  required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">PO Issue Date:</label>
                                <input type="date" class="form-control shadow-sm" name="po_issue_date">
                            </div>
                        </div>
                        <div class="row">
                           <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">PO acceptance date:</label>
                                <input type="date" class="form-control shadow-sm" name="po_acceptance_date">
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-label fw-bold">Validity of PO (from date):</div>
                                <input type="date" class="form-control shadow-sm" name="validity_of_po_from_date">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Validity of PO (to date):</label>
                                <input type="date" class="form-control shadow-sm" name="validity_of_po_to_date">
                            </div>
    
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">SLA Date</label>
                                <input type="date" class="form-control shadow-sm" name="sla_date">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Commercials (Rs.):</label>
                                <input type="text" class="form-control shadow-sm" name="commercials" step="0.01">
                            </div>
                            <div class="col-md-6 mb-3">
                                    <label class="form-label fw-bold">Category (Regulatory/Customer Centric/Back Office):</label>
                                    <select type="text" class="form-control shadow-sm" name="category">
                                        <option value="Regulatory">Regulatory</option>
                                        <option value="Customer-Centric">Customer Centric</option>
                                        <option value="Customer-Centric-Back-Office">Customer Centric And Back Office</option>
                                        <option value="Staff-Centric">Staff Centric</option>
                                        <option value="Back-Office">Back Office</option>
                                        <option value="Compliance">Compliance</option>
                                        <option value="Back-Office-Compliance">Back Office And Compliance</option>
                                    </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Payment Made Till Date:</label>
                                <input type="date" class="form-control shadow-sm" name="payment_made_till_date" >
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Last Date of Payment:</label>
                                <input type="date" class="form-control shadow-sm" name="last_date_of_payment" >
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">UAT Start Date:</label>
                                <input type="date" class="form-control shadow-sm" name="uat_start_date">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">UAT End Date:</label>
                                <input type="date" class="form-control shadow-sm" name="uat_end_date">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <div class="form-label fw-bold">Status:</div>
                                <select class="form-select shadow-sm mt-2" name="status"
                                style="width: inherit;
                                height: 2.5rem;"
                                >
                                <option value="In-Progress">In-Progress</option>
                                <option value="Completed"> Completed</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">% Complete:</label>
                            <input type="number" class="form-control shadow-sm" name="percentage_complete" min="0" max="100">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Current Status Details:</label>
                        <textarea type="text" class="form-control shadow-sm" name="current_status"></textarea>
                    </div>
                            
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Expected Time to Go-Live:</label>
                                <input type="date" class="form-control shadow-sm" name="expected_go_live">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Actual Go-Live date:</label>
                                <input type="date" class="form-control shadow-sm" name="actual_go_live_date">
                            </div>
                        </div>

                        <!-- <div class="mb-3">
                            <label class="form-label fw-bold">Benefits of Project:</label>
                            <textarea class="form-control shadow-sm" name="benefits_of_project" rows="3"></textarea>
                        </div> -->

                    
                        <!-- <div class="mb-3">
                            <label class="form-label fw-bold">Breakup of Payment Along with Dates:</label>
                            <textarea class="form-control shadow-sm" name="breakup_of_payment_made_along_with_dates" rows="3"></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Priority:</label>
                                <input type="text" class="form-control shadow-sm" name="priority">
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Task owner:</label>
                                <input type="text" class="form-control shadow-sm" name="task_owner">
                            </div>
                        </div>
                         -->
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Delay:</label>
                                <textarea type="text" class="form-control shadow-sm" name="delay" rows="3"></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Reason for delay:</label>
                                <textarea class="form-control shadow-sm" name="reason_for_delay" rows="3"></textarea>
                            </div>
                        </div>
<!--                         <div class="mb-3">
                            <label class="form-label fw-bold">Remarks by Project Lead:</label>
                            <textarea class="form-control shadow-sm" name="remarks_by_project_lead" rows="3"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">How to help to get business / Strategic Alignment:</label>
                                <textarea type="text" class="form-control shadow-sm" name="strategic_alignment"></textarea>
                            </div>  
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Dependence:</label>
                                <input type="text" class="form-control shadow-sm" name="dependence">
                            </div> -->
                            
                        </div> 



                        <div class="d-flex justify-content-center"
                        style="gap: 1rem;"
                        >
                            <button type="submit" class="btn btn-primary btn-lg me-2 shadow">Save</button>
                            <a href="{{ route('projects.index') }}" class="btn btn-secondary btn-lg shadow">Cancel</a>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
