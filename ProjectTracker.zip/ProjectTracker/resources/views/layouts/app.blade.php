<!DOCTYPE html>
<html>
<head>
    <title>Project Tracker</title>
  
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">


</head>
<body>
    @yield('content')
</body>
</html>
